let handPose;
let video;
let indexFinger = null; // Primer dedo índice (track 1)
let indexFinger2 = null; // Segundo dedo índice (track 2)
let audioPlayer1, audioPlayer2; // Reproductores de audio
let trail1 = []; // Rastro del track 1 (verde)
let trail2 = []; // Rastro del track 2 (rojo)

function preload() {
  handPose = ml5.handPose();
}

function setup() {
  createCanvas(windowWidth, windowHeight);

  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();
  handPose.detectStart(video, gotHands);

  // Cargar los archivos de audio
  audioPlayer1 = createAudio('track1.mp3'); // Ruta relativa al archivo
  audioPlayer2 = createAudio('track2.mp3'); // Ruta relativa al archivo

  // Configurar los reproductores de audio
  [audioPlayer1, audioPlayer2].forEach((player) => {
    player.loop(); // Reproducir en bucle
    player.volume(0); // Volumen inicial en 0 (silenciado)
    player.showControls(); // Mostrar controles del reproductor
  });
}

function draw() {
  // Fondo negro sólido
  background(0);

  // Dibujar el rastro del track 1 (verde)
  if (indexFinger) {
    let volume1 = map(indexFinger.y, 0, height, 1, 0); // Volumen basado en la posición Y
    let strokeWeight1 = map(volume1, 0, 1, 2, 10); // Grosor del trazo basado en el volumen
    noFill();
    stroke(0, 255, 0); // Color verde
    strokeWeight(strokeWeight1);
    beginShape();
    for (let i = 0; i < trail1.length; i++) {
      vertex(trail1[i].x, trail1[i].y);
    }
    endShape();
  }

  // Dibujar el rastro del track 2 (rojo)
  if (indexFinger2) {
    let volume2 = map(indexFinger2.y, 0, height, 1, 0); // Volumen basado en la posición Y
    let strokeWeight2 = map(volume2, 0, 1, 2, 10); // Grosor del trazo basado en el volumen
    noFill();
    stroke(255, 0, 0); // Color rojo
    strokeWeight(strokeWeight2);
    beginShape();
    for (let i = 0; i < trail2.length; i++) {
      vertex(trail2[i].x, trail2[i].y);
    }
    endShape();
  }

  // Controlar el track 1 con el primer dedo índice
  if (indexFinger) {
    // Controlar la velocidad (x)
    let speed1 = map(indexFinger.x, 0, width, 0.5, 2); // Mapear X a velocidad (0.5x - 2x)
    audioPlayer1.speed(speed1);

    // Controlar el volumen (y)
    let volume1 = map(indexFinger.y, 0, height, 1, 0); // Mapear Y a volumen (1 a 0, invertido)
    volume1 = constrain(volume1, 0, 1); // Asegurar que el volumen esté en el rango [0, 1]
    audioPlayer1.volume(volume1);

    // Guardar la posición actual del dedo índice en el rastro
    trail1.push({ x: indexFinger.x, y: indexFinger.y });

    // Ajustar la longitud máxima del rastro en función de la velocidad
    let maxTrailLength1 = map(speed1, 0.5, 2, 1000, 100); // Más velocidad = menos puntos
    if (trail1.length > maxTrailLength1) {
      trail1.shift(); // Limitar el tamaño del rastro
    }
  } else {
    // Si no se detecta el dedo, detener el track 1
    audioPlayer1.volume(0);
  }

  // Controlar el track 2 con el segundo dedo índice
  if (indexFinger2) {
    // Controlar la velocidad (x)
    let speed2 = map(indexFinger2.x, 0, width, 0.5, 2); // Mapear X a velocidad (0.5x - 2x)
    audioPlayer2.speed(speed2);

    // Controlar el volumen (y)
    let volume2 = map(indexFinger2.y, 0, height, 1, 0); // Mapear Y a volumen (1 a 0, invertido)
    volume2 = constrain(volume2, 0, 1); // Asegurar que el volumen esté en el rango [0, 1]
    audioPlayer2.volume(volume2);

    // Guardar la posición actual del dedo índice en el rastro
    trail2.push({ x: indexFinger2.x, y: indexFinger2.y });

    // Ajustar la longitud máxima del rastro en función de la velocidad
    let maxTrailLength2 = map(speed2, 0.5, 2, 1000, 100); // Más velocidad = menos puntos
    if (trail2.length > maxTrailLength2) {
      trail2.shift(); // Limitar el tamaño del rastro
    }
  } else {
    // Si no se detecta el dedo, detener el track 2
    audioPlayer2.volume(0);
  }

  // Dibujar la línea de tiempo de los tracks
  drawTimeline();
}

// Función para dibujar la línea de tiempo de los tracks
function drawTimeline() {
  let timelineHeight = 20;
  let timelineY = height - timelineHeight - 10;

  // Línea de tiempo del track 1 (izquierda)
  let progress1 = audioPlayer1.time() / audioPlayer1.duration();
  fill(0, 255, 0); // Color verde
  rect(10, timelineY, width / 2 - 20, timelineHeight);
  fill(255);
  rect(10, timelineY, (width / 2 - 20) * progress1, timelineHeight);

  // Línea de tiempo del track 2 (derecha)
  let progress2 = audioPlayer2.time() / audioPlayer2.duration();
  fill(255, 0, 0); // Color rojo
  rect(width / 2 + 10, timelineY, width / 2 - 20, timelineHeight);
  fill(255);
  rect(width / 2 + 10, timelineY, (width / 2 - 20) * progress2, timelineHeight);
}

// Función que recibe los datos de la detección de manos
function gotHands(results) {
  if (results.length > 0) {
    // Primer dedo índice (track 1)
    let hand1 = results[0];
    let keypoints1 = hand1.keypoints;
    indexFinger = keypoints1.find(point => point.name === 'index_finger_tip');

    if (indexFinger) {
      // Invertir la coordenada X para corregir la inversión de la cámara
      indexFinger.x = width - map(indexFinger.x, 0, video.width, 0, width);
      indexFinger.y = map(indexFinger.y, 0, video.height, 0, height);
    }

    // Segundo dedo índice (track 2)
    if (results.length > 1) {
      let hand2 = results[1];
      let keypoints2 = hand2.keypoints;
      indexFinger2 = keypoints2.find(point => point.name === 'index_finger_tip');

      if (indexFinger2) {
        // Invertir la coordenada X para corregir la inversión de la cámara
        indexFinger2.x = width - map(indexFinger2.x, 0, video.width, 0, width);
        indexFinger2.y = map(indexFinger2.y, 0, video.height, 0, height);
      }
    } else {
      indexFinger2 = null; // Si no hay segunda mano, reiniciar el segundo dedo
    }
  } else {
    indexFinger = null;
    indexFinger2 = null;
  }
}